const fs = require('fs')

global.nameStyle = "𝘄𝗮𝗹𝗸𝗲𝗿'𝗌 𝗌𝗍𝗈𝗋𝖾ㅤ🦇"
global.pairing = true  // ganti false jika ingin scan dan ganti true untuk menggunakan pairing code
global.namabot = "𝘄𝗮𝗹𝗸𝗲𝗿'𝗌 𝗌𝗍𝗈𝗋𝖾ㅤ🦇"
global.botname = "𝘄𝗮𝗹𝗸𝗲𝗿'𝗌 𝗌𝗍𝗈𝗋𝖾ㅤ🦇"
global.namaowner = "WALKER"
global.footer_text = "𝘄𝗮𝗹𝗸𝗲𝗿'𝗌 𝗌𝗍𝗈𝗋𝖾ㅤ🦇" + namabot
global.pp_bot = fs.readFileSync("./image/foto.jpg")
global.qris = fs.readFileSync("./image/qris.jpg")
global.owner = ['0882016638931']
global.sessionName = 'session'
global.packname = "Sticker By"
global.author = "\n\n\n\n\nCreate by flixbot v22\nNo hape/wa : 62"
global.prefa = ['-_-']
global.caption_pay = `Qris All Pay\nOvo\nDana\nGopay\n\nMau ganti payment? ketik .setpay\n`

let file = require.resolve(__filename);
fs.watchFile(file, () => {
  fs.unwatchFile(file);
  console.log(`Update ${__filename}`);
  delete require.cache[file];
  require(file);
});

// Website Topup : https://richmarket.id
// Website SMM : https://richmarket-smm.id
// Instagram : https://www.instagram.com/richmarket.id
// YouTube : https://youtube.com/
// Github : https://github.com/
// Shopee : https://shopee.co.id/