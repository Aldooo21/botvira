// Website Topup : https://richmarket.id
// Website SMM : https://richmarket-smm.id
// Instagram : https://www.instagram.com/richmarket.id
// YouTube : https://youtube.com/
// Github : https://github.com/
// Shopee : https://shopee.co.id/
// WhatsApp : 6282276853797
// Untuk informasi lebih lanjut silahkan hubungi nomor diatas
// Reseller Welcome ✅
require('./settings')
const { BufferJSON, WA_DEFAULT_EPHEMERAL, generateWAMessageFromContent, proto, generateWAMessageContent, generateWAMessage, prepareWAMessageMedia, areJidsSameUser, getContentType } = require('@whiskeysockets/baileys')
const fs = require('fs');
const util = require('util');
const chalk = require('chalk');
const axios = require('axios');
const os = require('os')
const { performance } = require('perf_hooks')
const speed = require('performance-now')
const moment = require('moment-timezone');
const { sizeFormatter } = require('human-readable')
const ms = toMs = require('ms');
const FormData = require("form-data");
const { fromBuffer } = require('file-type')
const fetch = require('node-fetch')
const md5 = require('md5');
const crypto = require("crypto")
const hikki = require("hikki-me");
const remini = require('./lib/scraper/remini');
const api = require("caliph-api");
const { exec, spawn, execSync } = require("child_process")
const jsobfus = require('javascript-obfuscator')
const set_bot = JSON.parse(fs.readFileSync('./database/set_bot.json'));
const { smsg, fetchJson, getBuffer } = require('./lib/simple')
const antilinkgc = JSON.parse(fs.readFileSync('./database/antilinkgc.json'))    
const { 
  isSetBot,
    addSetBot,
    removeSetBot,
    changeSetBot,
    getTextSetBot,
  updateResponList,
  delResponList,
  renameList,
  isAlreadyResponListGroup,
  sendResponList,
  isAlreadyResponList,
  getDataResponList,
  addResponList,
  isSetClose,
    addSetClose,
    removeSetClose,
    changeSetClose,
    getTextSetClose,
    isSetDone,
    addSetDone,
    removeSetDone,
    changeSetDone,
    getTextSetDone,
    isSetLeft,
    addSetLeft,
    removeSetLeft,
    changeSetLeft,
    getTextSetLeft,
    isSetOpen,
    addSetOpen,
    removeSetOpen,
    changeSetOpen,
    getTextSetOpen,
    isSetProses,
    addSetProses,
    removeSetProses,
    changeSetProses,
    getTextSetProses,
    isSetWelcome,
    addSetWelcome,
    removeSetWelcome,
    changeSetWelcome,
    getTextSetWelcome,
    addSewaGroup,
    getSewaExpired,
    getSewaPosition,
    expiredCheck,
    checkSewaGroup,
    addPay,
    updatePay
} = require("./lib/store")

async function getGroupAdmins(participants){
        let admins = []
        for (let i of participants) {
            i.admin === "superadmin" ? admins.push(i.id) :  i.admin === "admin" ? admins.push(i.id) : ''
        }
        return admins || []
}

async function TelegraPh(imagePath) {
const cloudinary = require("cloudinary").v2;
cloudinary.config({
  cloud_name: "ddirzdaxp",
  api_key: "768934877945677",
  api_secret: "Kd00aYPWqpnolsTp9nllZHiCmj4",
});
  try {
    const result = await cloudinary.uploader.upload(imagePath, {});
    return result.secure_url;
  } catch (error) {
    console.error("Gagal upload:", error);
    throw error;
  }
}

		function formatmoney(n, opt = {}) {
		  if (!opt.current) opt.current = "IDR"
		  return "Rp." + n.toFixed(0).replace(/\B(?=(\d{3})+(?!\d))/g, ",")
        }
function toRupiah(angka) {
			var angkaStr = angka.toString();
			var angkaTanpaKoma = angkaStr.split('.')[0];
			var angkaRev = angkaTanpaKoma.toString().split('').reverse().join('');
			var rupiah = '';
	for (var i = 0; i < angkaRev.length; i++) {
	  if (i % 3 == 0) rupiah += angkaRev.substr(i, 3) + '.';
	}
	return '' + rupiah.split('', rupiah.length - 1).reverse().join('');
  }
  function toLvl(angka) {
	if (angka < 10) {
	  return `1.0${angka}`;
	}
  if (angka < 100) {
	  return `1.${angka}`;
	}
	if (angka < 1000) {
	  return `${Math.floor(angka / 100)}.${Math.floor((angka % 100) / 10)}`;
	}
	return `${Math.floor(angka / 1000) * 10}`;
  }
function runtime(seconds) {

	seconds = Number(seconds);

	var d = Math.floor(seconds / (3600 * 24));
	var h = Math.floor(seconds % (3600 * 24) / 3600);
	var m = Math.floor(seconds % 3600 / 60);
	var s = Math.floor(seconds % 60);
	var dDisplay = d > 0 ? d + (d == 1 ? " day, " : " days, ") : "";
	var hDisplay = h > 0 ? h + (h == 1 ? " hour, " : " hours, ") : "";
	var mDisplay = m > 0 ? m + (m == 1 ? " minute, " : " minutes, ") : "";
	var sDisplay = s > 0 ? s + (s == 1 ? " second" : " seconds") : "";
	return dDisplay + hDisplay + mDisplay + sDisplay;
}
function msToDate(mse) {
               temp = mse
               days = Math.floor(mse / (24 * 60 * 60 * 1000));
               daysms = mse % (24 * 60 * 60 * 1000);
               hours = Math.floor((daysms) / (60 * 60 * 1000));
               hoursms = mse % (60 * 60 * 1000);
               minutes = Math.floor((hoursms) / (60 * 1000));
               minutesms = mse % (60 * 1000);
               sec = Math.floor((minutesms) / (1000));
               return days + " Days " + hours + " Hours " + minutes + " Minutes";
            }
            
const isUrl = (url) => {
    return url.match(new RegExp(/https?:\/\/(www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_+.~#?&/=]*)/, 'gi'))
}

const time2 = moment().tz('Asia/Jakarta').format('HH:mm:ss')  
 if(time2 < "23:59:00"){
var ucapanWaktu2 = '𝘚𝘦𝘭𝘢𝘮𝘢𝘵 𝘔𝘢𝘭𝘢𝘮 🐋'
 }
 if(time2 < "19:00:00"){
var ucapanWaktu2 = '𝘚𝘦𝘭𝘢𝘮𝘢𝘵 𝘚𝘰𝘳𝘦 🦈'
 }
 if(time2 < "18:00:00"){
var ucapanWaktu2 = '𝘚𝘦𝘭𝘢𝘮𝘢𝘵 𝘚𝘰𝘳𝘦 🐝'
 }
 if(time2 < "15:00:00"){
var ucapanWaktu2 = '𝘚𝘦𝘭𝘢𝘮𝘢𝘵 𝘚𝘪𝘢𝘯𝘨 🦭'
 }
 if(time2 < "11:00:00"){
var ucapanWaktu2 = '𝘚𝘦𝘭𝘢𝘮𝘢𝘵 𝘗𝘢𝘨𝘪 🐠'
 }
 if(time2 < "05:00:00"){
var ucapanWaktu2 = '𝘚𝘦𝘭𝘢𝘮𝘢𝘵 𝘗𝘢𝘨𝘪 🦚'
 } 

async function obfus(query) {
return new Promise((resolve, reject) => {
try {
const obfuscationResult = jsobfus.obfuscate(query,
{
compact: false,
controlFlowFlattening: true,
controlFlowFlatteningThreshold: 1,
numbersToExpressions: true,
simplify: true, 
stringArrayShuffle: true,
splitStrings: true,
stringArrayThreshold: 1
}
);
const result = {
status: 200,
author: `Arbakti`,
result: obfuscationResult.getObfuscatedCode()
}
resolve(result)
} catch (e) {
reject(e)
}
})
}

async function UploadDulu(medianya, options = {}) {
const { ext } = await fromBuffer(medianya) || options.ext
        var form = new FormData()
        form.append('file', medianya, 'tmp.'+ext)
        let jsonnya = await fetch('https://tenaja.zeeoneofc.repl.co/upload', {
                method: 'POST',
                body: form
        })
        .then((response) => response.json())
        return jsonnya
}

const sleep = async (ms) => {
return new Promise(resolve => setTimeout(resolve, ms));
}
let d = new Date
let locale = 'id'
const tanggalnew = d.toLocaleDateString(locale, { day: 'numeric', month: 'long', year: 'numeric' })
const tanggal = (numer) => {
	myMonths = ["Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember"];
				myDays = ['Minggu','Senin','Selasa','Rabu','Kamis','Jum’at','Sabtu']; 
				var tgl = new Date(numer);
				var day = tgl.getDate()
				bulan = tgl.getMonth()
				var thisDay = tgl.getDay(),
				thisDay = myDays[thisDay];
				var yy = tgl.getYear()
				var year = (yy < 1000) ? yy + 1900 : yy; 
				const time = moment.tz('Asia/Jakarta').format('DD/MM HH:mm:ss')
				let d = new Date
				let locale = 'id'
				let gmt = new Date(0).getTime() - new Date('1 January 1970').getTime()
				let weton = ['Pahing', 'Pon','Wage','Kliwon','Legi'][Math.floor(((d * 1) + gmt) / 84600000) % 5]
				
				return`${thisDay}, ${day} - ${myMonths[bulan]} - ${year}`
}

module.exports = arbakti = async (arbakti, m, chatUpdate, store, opengc, setpay, antilink, antiwame, antilink2, antiwame2, set_welcome_db, set_left_db, set_proses, set_done, set_open, set_close, sewa, _welcome, _left, db_respon_list, spamBot, prem_db) => {
    try {
var body = (
m.mtype === 'conversation' ? m.message.conversation :
m.mtype === 'imageMessage' ? m.message.imageMessage.caption :
m.mtype === 'videoMessage' ? m.message.videoMessage.caption :
m.mtype === 'extendedTextMessage' ? m.message.extendedTextMessage.text :
m.mtype === 'buttonsResponseMessage' ? m.message.buttonsResponseMessage.selectedButtonId :
m.mtype === 'listResponseMessage' ? m.message.listResponseMessage.singleSelectReply.selectedRowId :
m.mtype === 'interactiveResponseMessage' ? JSON.parse(m.message.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson).id :
m.mtype === 'templateButtonReplyMessage' ? m.message.templateButtonReplyMessage.selectedId :
m.mtype === 'messageContextInfo' ?
m.message.buttonsResponseMessage?.selectedButtonId ||
m.message.listResponseMessage?.singleSelectReply.selectedRowId ||
m.message.InteractiveResponseMessage.NativeFlowResponseMessage ||
m.text :
''
);
        var budy = (typeof m.text == 'string' ? m.text : '')
        var prefix = prefa ? /^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi.test(body) ? body.match(/^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi)[0] : "" : prefa ?? global.prefix
        const isCmd = body.startsWith(prefix)
        const command = body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase()
        const args = body.trim().split(/ +/).slice(1)
        const pushname = m.pushName || "No Name"
        const botNumber = await arbakti.decodeJid(arbakti.user.id)
        const isCreator = ["62895383507983@s.whatsapp.net",botNumber, ...global.owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
        const isLins = ["628981700532@s.whatsapp.net",botNumber, ...global.owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
        const text = q = args.join(" ")
        const quoted = m.quoted ? m.quoted : m
        const mime = (quoted.msg || quoted).mimetype || ''
        const isMedia = /image|video|sticker|audio/.test(mime)
        const groupMetadata = m.isGroup ? await arbakti.groupMetadata(m.chat).catch(e => {}) : ''
        const groupName = m.isGroup ? groupMetadata.subject : ''
        const participants = m.isGroup ? await groupMetadata.participants : ''
        const groupAdmins = m.isGroup ? await getGroupAdmins(participants) : ''
      	const isBotAdmins = m.isGroup ? groupAdmins.includes(botNumber) : false
      	const isAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false
      	const isSewa = checkSewaGroup(m.chat, sewa)
        const isAntiLink = antilink.includes(m.chat) ? true : false
        const isAntiWame = antiwame.includes(m.chat) ? true : false  
        const isAntiLink2 = antilink2.includes(m.chat) ? true : false
        const isAntiWame2 = antiwame2.includes(m.chat) ? true : false  
        const isAntiLinkgc = m.isGroup ? antilinkgc.includes(m.chat) : false
const isWelcome = _welcome.includes(m.chat)
const isLeft = _left.includes(m.chat)
const jam = moment.tz('asia/jakarta').format('HH:mm:ss')
const time = moment(Date.now()).tz('Asia/Jakarta').locale('id').format('HH:mm:ss z')
const jamsolat = moment(Date.now()).tz('Asia/Jakarta').locale('id').format('HH:mm')
const from = m.key.remoteJid
const reply = (text) =>{
  m.reply(text)
}
const content = JSON.stringify(m.message)
const isImage = (m == 'imageMessage')
const isQuotedMsg = (m.mtype == 'extendedTextMessage')
const isQuotedImage = m === 'extendedTextMessage' && content.includes('imageMessage')
const isQuotedSticker = isQuotedMsg ? content.includes('stickerMessage') ? true : false : false 
const qmsg = (quoted.msg || quoted)
async function getGcName(groupID) {
            try {
                let data_name = await arbakti.groupMetadata(groupID)
                return data_name.subject
            } catch (err) {
                return '-'
            }
        }

async function getGcOwn(groupID) {
            try {
                let data_name = await arbakti.groupMetadata(groupID)
                return "wa.me/" + data_name.owner.split("@")[0]
            } catch (err) {
                return '-'
            }
        }
        
        if (m.message) {
            arbakti.readMessages([m.key])
            console.log(chalk.black(chalk.bgWhite('[ CMD ]')), chalk.black(chalk.bgGreen(new Date)), chalk.black(chalk.bgBlue(budy || m.mtype)) + '\n' + chalk.magenta('=> From'), chalk.green(pushname), chalk.yellow(m.sender) + '\n' + chalk.blueBright('=> In'), chalk.green(m.isGroup ? pushname : 'Chat Pribadi', m.chat))
        }

const fitur = () => {
var mytext = fs.readFileSync("./vortex.js").toString()
var cases = mytext.match(/(?<=case\s').*?(?=':)/g) || [];
return cases;
}

const cmdCase = fitur().includes(command)
let targetSpam = []

spamBot.ResetSpam(targetSpam)

const spamBotLins = () => {
spamBot.addSpam(m.sender, targetSpam)
reply('Anda Terdereksi Spam!! Jangan Spam Bot Beri Waktu Jeda 5 Detik')
}

if (cmdCase && spamBot.isFiltered(m.sender)) return spamBotLins()
if (cmdCase && args.length < 1) spamBot.addFilter(m.sender)

if(m.isGroup){
    expiredCheck(arbakti, sewa)
}

       try {
    if (isAntiLinkgc) {
        if (budy.includes('https://chat.whatsapp.com/')) {
        if (isAdmins) return m.reply(`Upsss... gak jadi, kasian admin`)
        if (isCreator) return m.reply(`Upsss... gak jadi, kasian owner`)
        reply(`*「 LINK DETECTOR 」* \n\nTERDETEKSI MENGIRIM LINK GRUP ORANG LAIN SORY BOT AKAN HAPUS PESAN ANDA`);
            await arbakti.sendMessage(m.chat, {
                delete: {
                    remoteJid: m.chat,
                    fromMe: false,
                    id: m.key.id,
                    participant: m.key.participant
                }
            });
            arbakti.sendMessage(from, { delete: m.key });
        }
    }
} catch (error) {
    console.error(error);
    reply('Terjadi kesalahan saat menjalankan perintah link detector.');
}
      if (isAntiLink) {
        if (budy.match(`chat.whatsapp.com`)) {
        m.reply(`*「 ANTI LINK 」*\n\nLink grup detected, maaf kamu akan di kick !`)
        if (!isBotAdmins) return m.reply(`Upsss... gajadi, bot bukan admin`)
        let gclink = (`https://chat.whatsapp.com/`+await arbakti.groupInviteCode(m.chat))
        let isLinkThisGc = new RegExp(gclink, 'i')
        let isgclink = isLinkThisGc.test(m.text)
        if (isgclink) return m.reply(`Upsss... gak jadi, untung link gc sendiri`)
        if (isAdmins) return m.reply(`Upsss... gak jadi, kasian adminnya klo di kick`)
        if (isCreator) return m.reply(`Upsss... gak jadi, kasian owner ku klo di kick`)
        if (m.key.fromMe) return m.reply(`Upsss... gak jadi, kasian owner ku klo di kick`)
await arbakti.sendMessage(m.chat, {
               delete: {
                  remoteJid: m.chat,

                  fromMe: false,
                  id: m.key.id,
                  participant: m.key.participant
               }
            })
        arbakti.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
        }
        }
      if (isAntiLink2) {
        if (budy.match(`chat.whatsapp.com`)) {
        if (!isBotAdmins) return //m.reply(`Upsss... gajadi, bot bukan admin`)
        let gclink = (`https://chat.whatsapp.com/`+await arbakti.groupInviteCode(m.chat))
        let isLinkThisGc = new RegExp(gclink, 'i')
        let isgclink = isLinkThisGc.test(m.text)
        if (isgclink) return //m.reply(`Upsss... gak jadi, untung link gc sendiri`)
        if (isAdmins) return //m.reply(`Upsss... gak jadi, kasian adminnya klo di kick`)
        if (isCreator) return //m.reply(`Upsss... gak jadi, kasian owner ku klo di kick`)
        if (m.key.fromMe) return //m.reply(`Upsss... gak jadi, kasian owner ku klo di kick`)
await arbakti.sendMessage(m.chat, {
               delete: {
                  remoteJid: m.chat,

                  fromMe: false,
                  id: m.key.id,
                  participant: m.key.participant
               }
            })
        }
        }
      if (isAntiWame) {
        if (budy.match(`wa.me/`)) {
        m.reply(`*「 ANTI WA ME 」*\n\nWa Me detected, maaf kamu akan di kick !`)
        if (!isBotAdmins) return m.reply(`Upsss... gajadi, bot bukan admin`)
        if (isAdmins) return m.reply(`Upsss... gak jadi, kasian adminnya klo di kick`)
        if (isCreator) return m.reply(`Upsss... gak jadi, kasian owner ku klo di kick`)
        if (m.key.fromMe) return m.reply(`Upsss... gak jadi, kasian owner ku klo di kick`)
await arbakti.sendMessage(m.chat, {
               delete: {
                  remoteJid: m.chat,

                  fromMe: false,
                  id: m.key.id,
                  participant: m.key.participant
               }
            })        
        arbakti.sendMessage(from, { delete: m.key });
        arbakti.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
        }
        }
      if (isAntiWame2) {
        if (budy.match(`wa.me/`)) {
        if (!isBotAdmins) return m.reply(`Upsss... gajadi, bot bukan admin`)
        if (isAdmins) return m.reply(`Upsss... gak jadi, kasian adminnya klo di kick`)
        if (isCreator) return m.reply(`Upsss... gak jadi, kasian owner ku klo di kick`)
        if (m.key.fromMe) return m.reply(`Upsss... gak jadi, kasian owner ku klo di kick`)
        reply(`*「 LINK DETECTOR 」* \n\nTERDETEKSI MENGIRIM WA.ME SORY BOT AKAN HAPUS PESAN ANDA`);
await arbakti.sendMessage(m.chat, {
               delete: {
                  remoteJid: m.chat,

                  fromMe: false,
                  id: m.key.id,
                  participant: m.key.participant
               }
            })        
        }
        }
      if (isAntiWame) {
        if (budy.includes((`Wa.me/`) || (`Wa.me/`))) {
        m.reply(`*「 ANTI WA ME 」*\n\nWa Me detected, maaf kamu akan di kick !`)
        if (!isBotAdmins) return m.reply(`Upsss... gajadi, bot bukan admin`)
        if (isAdmins) return m.reply(`Upsss... gak jadi, kasian adminnya klo di kick`)
        if (isCreator) return m.reply(`Upsss... gak jadi, kasian owner ku klo di kick`)
        if (m.key.fromMe) return m.reply(`Upsss... gak jadi, kasian owner ku klo di kick`)
        arbakti.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
        }
        }
        
        if (isAlreadyResponList((m.isGroup ? m.chat: botNumber), body.toLowerCase(), db_respon_list)) {
            var get_data_respon = getDataResponList((m.isGroup ? m.chat: botNumber), body.toLowerCase(), db_respon_list)
            if (get_data_respon.isImage === false) {
                arbakti.sendMessage(m.chat, { text: sendResponList((m.isGroup ? m.chat: botNumber), body.toLowerCase(), db_respon_list) }, {
                    quoted: m
                })
            } else {
                arbakti.sendMessage(m.chat, { image: await getBuffer(get_data_respon.image_url), caption: get_data_respon.response }, {
                    quoted: m
                })
            }
        }

const formatp = sizeFormatter({
    std: 'JEDEC', //'SI' = default | 'IEC' | 'JEDEC'
    decimalPlaces: 2,
    keepTrailingZeroes: false,
    render: (literal, symbol) => `${literal} ${symbol}B`,
})
        
let profil = await getBuffer("https://files.catbox.moe/ro399g.jpg")

const replyDiteruskan = (teks) => { 
arbakti.sendMessage(from, { text: teks, contextInfo: { 
"mentionedJid": [m.sender],
"forwardingScore": 9999999, 
"isForwarded": true, 
"externalAdReply": { 
"showAdAttribution": true, 
"title": "PT. ARBAKTI STORE DEVELOPMENT", 
"mediaType": 1, 
"thumbnail":  profil,
"mediaUrl": "https://chat.whatsapp.com/FkK9IWteM6tKmIV36DkjP8", 
"sourceUrl": "https://chat.whatsapp.com/FkK9IWteM6tKmIV36DkjP8" }}

}, { quoted: m }) }

async function diteruskanAudio(voice, judul, tubuh, gambar, link ) {
arbakti.sendMessage(from, { audio: fs.readFileSync(voice), 
mimetype: 'audio/mp4', 
ptt: true , 
contextInfo: { 
"mentionedJid": [m.sender],
"forwardingScore": 9999999, 
"isForwarded": true, 
"externalAdReply": { "showAdAttribution": true, 
"title": judul, 
"body": tubuh,
"mediaType": 1, 
"thumbnail":  await getBuffer(gambar),
"mediaUrl": link, 
"sourceUrl": link }}}, {quoted:m})
}

async function iklanAudio(voice, judul, tubuh, gambar, link){
arbakti.sendMessage(from, { audio: fs.readFileSync(voice), 
mimetype: 'audio/mp4', 
ptt: true , 
contextInfo: { 
"externalAdReply": { 
"showAdAttribution": true, 
"title": judul,
"body": tubuh,
"containsAutoReply": true, 
"mediaType": 1, 
"thumbnail": await getBuffer(gambar),
"mediaUrl": link, 
"sourceUrl": link }}}, {quoted:m})

}

function sendImage(link, txt){
arbakti.sendMessage(from, {image:{url:link}, caption: txt}, {quoted: m})
}

function sendVideo(link, txt){
arbakti.sendMessage(from, {video: {url: link}, caption: txt}, {quotes: m} )
}
 
function mentions(teks, mems = [], id) {
if (id == null || id == undefined || id == false) {
let res = arbakti.sendMessage(from, { text: teks, mentions: mems }, { quoted: m })
return res
} else {
let res = arbakti.sendMessage(from, { text: teks, mentions: mems }, { quoted: m })
return res
}
}

function formatmoney(n, opt = {}) {
		  if (!opt.current) opt.current = "IDR"
		  return "Rp. " + n.toFixed(0).replace(/\B(?=(\d{3})+(?!\d))/g, ",")
		}
		
function toRupiah(angka) {
  var angkaStr = angka.toString();
  var angkaTanpaKoma = angkaStr.split('.')[0];
  var angkaRev = angkaTanpaKoma.toString().split('').reverse().join('');
  var rupiah = '';
  for (var i = 0; i < angkaRev.length; i++) {
    if (i % 3 == 0) rupiah += angkaRev.substr(i, 3) + '.';
  }
  return '' + rupiah.split('', rupiah.length - 1).reverse().join('');
}

switch(command) {

         case 'owner':
         case 'creator': {
            arbakti.sendContact(m.chat, global.owner, m)
         }
         break
          case 'mbayar': case 'scanqris': case 'ayobayar':{
const getTextSetDone = (groupID, _db) => {
    let position = null
    Object.keys(_db).forEach((x) => {
        if (_db[x].id === groupID) {
            position = x
        }
    })
    if (position !== null) {
        return _db[position]
    }
}

let bentargwcekpaynya = await getTextSetDone(m.isGroup? m.chat: botNumber, setpay)
if (bentargwcekpaynya !== undefined) {
arbakti.sendMessage(m.chat, {image: await getBuffer(bentargwcekpaynya.pay), caption: bentargwcekpaynya.caption}, {quoted:m})
} else {
arbakti.sendMessage(m.chat, {image: qris, caption: caption_pay}, {quoted:m})
          }
          }
          break
		case 'list': case 'menu':{
            if (db_respon_list.length === 0) return m.reply(`_Belum ada list apapun kak_`)
            if (!isAlreadyResponListGroup((m.isGroup ? m.chat: botNumber), db_respon_list)) return m.reply(`_Belum ada list apapun kak_`)
            if(m.isGroup){
            let teks = `. 𖢷 ׁ ᳸ @${m.sender.split("@")[0]}\n꒰〝 *𝗉𝗂𝗋𝖺𝗍𝖾'𝗌*! 𝗌𝗍𝖺𝗋𝗍 𝗍𝗁𝖾 𝗌𝗍𝗈𝗋𝗒 𝖻𝗒 𝗈𝗉𝖾𝗇𝗂𝗇𝗀 𝖺 𝗌𝗍𝗈𝗋𝖾'𝗌 𝗆𝖾𝗇𝗎 𝗆𝖾𝗌𝗌𝖺𝗀𝖾! 𝖼𝗁𝖾𝖼𝗄 𝗂𝗍 𝗇𝗈𝗐!\n\n${groupName}\n\n⸼ ꮺ 𝗍𝖺𝗇𝗀𝗀𝖺𝗅 ⵓ ${tanggal(new Date())}\n⸼ ꮺ 𝗃𝖺𝗆 ⵓ ${jam}\n\n￮ ׂ ꒰꒰ 𝗰𝗮𝘁𝗮𝗹𝗼𝗴𝘂𝗲 ⊰ׁ\n𓈈 🍒 𝗉𝗂𝗋𝖺𝗍𝖾 𝗌𝗍𝗈𝗋𝖾'𝗌\n›\n\n`
            for (let i of db_respon_list) {
              if (i.id === (m.isGroup ? m.chat : botNumber)) {
               teks += `.   ┆ ⸼ ࣪ 𖹭  ࣪𝃯 𓂂  *${i.key.toLowerCase()}*\n`
              }
            }
              teks += `\n𓈄 °  ִ𝗉𝗅𝖾𝖺𝗌𝖾 𝗋𝖾𝖺𝖽 𝗍𝗁𝖾 ₎ა  ࣪ 𝗀𝗋𝗈𝗎𝗉\n𝗋𝗎𝗅𝖾𝗌 𑣿 ┄ · 𝖻𝖾 𝖼𝖺𝗋𝖾𝖿𝗎𝗅 𝗐𝗂𝗍𝗁 𝖼𝗅𝗈𝗇𝖾\nᨧᨴ ִ ۫ ─┄─┈ ִ ׄ ⸼ 𝗇𝗎𝗆𝖻𝖾𝗋'𝗌 !`
              sendImage("https://files.catbox.moe/8fyo6a.jpg", teks)
            } else {
            var arr_rows = [];
            for (let x of db_respon_list) {
               if (x.id === (m.isGroup ? m.chat : botNumber)) {
                  arr_rows.push({
                     title: x.key,
                     rowId: x.key
                  })
               }
            }
            var listMsg = {
               text: `Halo @${m.sender.split("@")[0]} 👋\n\nSilahkan pilih item yang kamu butuhkan 🌟`,
               buttonText: 'Click Here',
               footer: footer_text,
               mentions: [m.sender],
               sections: [{
                  title: groupName,
                  rows: arr_rows
               }]
            }
            arbakti.sendMessage(m.chat, listMsg, {
               quoted: m
            })
            }
			}
            break
			case 'dellist':{
	       // if (!m.isGroup) return m.reply('Fitur Khusus Group!')
			if (!(m.isGroup? isAdmins : isCreator)) return m.reply('Fitur Khusus Admin & Ustadz VORTEX!')
            if (db_respon_list.length === 0) return m.reply(`Belum ada list message di database`)
            if (!text) return m.reply(`Gunakan dengan cara ${prefix + command} *key*\n\n_Contoh_\n\n${prefix + command} hello`)
            if (!isAlreadyResponList((m.isGroup? m.chat: botNumber), q.toLowerCase(), db_respon_list)) return m.reply(`Waduh, List Respon Dengan Kode *${q}* Tidak Ada Di Hatiku!`)
            delResponList((m.isGroup? m.chat: botNumber), q.toLowerCase(), db_respon_list)
            reply(`Sukses Menghapus Kenangan Dengan Kode *${q}*`)
			}
            break
            case 'dellistall':{
			if (!(m.isGroup? isAdmins : isCreator)) return m.reply('Fitur Khusus Admin & Ustadz VORTEX!')
			let filteredData = db_respon_list.filter(item => item.id !== m.chat);
			fs.writeFileSync('./database/list.json', JSON.stringify(filteredData, null, 2));
			reply('done')
			await sleep(100)
let cp = require('child_process')
let { promisify } = require('util')
let exec = promisify(cp.exec).bind(cp)
  let o
  try {
  o = exec('pm2 restart all')
  } catch (e) {
  o = e
 } finally {
let { stdout, stderr } = o
}
			
			}
            break
            case 'restart':{
            reply('done')
 let cp = require('child_process')
let { promisify } = require('util')
let exec = promisify(cp.exec).bind(cp)
  let o
  try {
  o = exec('pm2 restart all')
  } catch (e) {
  o = e
 } finally {
let { stdout, stderr } = o
}}
break
case 'setmbayar': case 'settumbas':{
if (!(m.isGroup? isAdmins : isCreator)) return m.reply('Fitur Khusus Admin & Ustadz VORTEX!')
if(!text) return m.reply(`Reply payment dengan caption ${prefix + command} *caption*\n\n_Contoh_\n\n${prefix + command} Ini Kak Paymentnya`)
if (!/image/.test(mime)) return m.reply(`Reply Payment Dengan Caption ${prefix + command} *caption*\n\n_Contoh_\n\n${prefix + command} Ini Kak Paymentnya`)
let dwnld = await arbakti.downloadMediaMessage(quoted)
let nungguya = await UploadDulu(dwnld) 
if(isAlreadyResponListGroup(m.isGroup? m.chat: botNumber, setpay)){
updatePay(m.isGroup? m.chat:botNumber, nungguya.result.url, text, setpay)
} else {
addPay(m.isGroup? m.chat:botNumber, nungguya.result.url, text, setpay)
}
reply("Done Set Payment")
}
break
			case'addlist':{
            //if (!m.isGroup) return m.reply('Fitur Khusus Group!')
			if (!(m.isGroup? isAdmins : isCreator)) return m.reply('Fitur Khusus Admin & Ustadz VORTEX!')
            var args1 = q.split("|")[0].toLowerCase()
            var args2 = q.split("|")[1]
            if (!q.includes("|")) return m.reply(`Gunakan Dengan Cara ${command} *key|response*\n\n_Contoh_\n\n${command} tes|apa`)
            if (isAlreadyResponList((m.isGroup ? m.chat :botNumber), args1, db_respon_list)) return m.reply(`List Respon Dengan Kode : *${args1}* Sudah Ada Di Hatiku.`)
            if(m.isGroup){
            if (/image/.test(mime)) {
                let media = await arbakti.downloadAndSaveMediaMessage(quoted)
                let mem = await TelegraPh(media)
                        addResponList(m.chat, args1, args2, true, mem, db_respon_list)
                        reply(`Sukses Menambah Kenangan Dengan Kode : *${args1}*`)
                        if (fs.existsSync(media)) fs.unlinkSync(media)
            } else {
                addResponList(m.chat, args1, args2, false, '-', db_respon_list)
                reply(`Sukses Menambah Kenangan Dengan Kode : *${args1}*`)
            }
            } else {
            if (/image/.test(mime)) {
                let media = await arbakti.downloadAndSaveMediaMessage(quoted)
                let mem = await TelegraPh(media)
                        addResponList(botNumber, args1, args2, true, mem, db_respon_list)
                        reply(`Sukses Menambah Kenangan Dengan Kode : *${args1}*`)
                        if (fs.existsSync(media)) fs.unlinkSync(media)
            } else {
                addResponList(botNumber, args1, args2, false, '-', db_respon_list)
                reply(`Sukses Menambah Kenangan Dengan Kode : *${args1}*`)
            }
            }
			}
            break
case 'setdesc': case 'setdesk': {
                if (!m.isGroup) return m.reply('Fitur Khusus Group!')
				if (!isAdmins) return m.reply('Fitur Khusus Admin!')
                if (!isBotAdmins) return m.reply("Jadikan *Bot* Sebagai Admin")
                if (!text) return m.reply(`Example ${prefix + command} WhatsApp Bot`)
                await arbakti.groupUpdateDescription(m.chat, text).then((res) => m.reply("Done")).catch((err) => {
                 erorSys(err)
                 m.reply("Terjadi kesalahan")
                })
            }
            break
case 'promote': {
		if (!m.isGroup) return m.reply('Fitur Khusus Group!')
				if (!isAdmins) return m.reply('Fitur Khusus Admin!')
                if (!isBotAdmins) return m.reply("Jadikan *Bot* Sebagai Admin")
		let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
		await arbakti.groupParticipantsUpdate(m.chat, [users], 'promote').then((res) => m.reply('Sukses Menaikkan Jabatan Member✅')).catch((err) => m.reply('❌ Terjadi Kesalahan'))
	}
	break
	case 'demote': {
		if (!m.isGroup) return m.reply('Fitur Khusus Group!')
				if (!isAdmins) return m.reply('Fitur Khusus Admin!')
                if (!isBotAdmins) return m.reply("Jadikan *Bot* Sebagai Admin")
		let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
		await arbakti.groupParticipantsUpdate(m.chat, [users], 'demote').then((res) => m.reply('Sukses Menurunkan Jabatan Admin✅')).catch((err) => m.reply('❌ Terjadi kesalahan'))
	}
	break
case 'setlinkgc': case'revoke':{
            if (!m.isGroup) return m.reply('Fitur Khusus Group!')
				if (!isAdmins) return m.reply('Fitur Khusus Admin!')
                if (!isBotAdmins) return m.reply("Jadikan *Bot* Sebagai Admin")
            await arbakti.groupRevokeInvite(m.chat)
            .then( res => {
                reply(`Sukses Menyetel Tautan Undangan Grup Ini`)
            }).catch(() => reply("Terjadi Kesalahan"))
}
            break
case 'linkgrup': case 'linkgroup': case 'linkgc': {
                if (!m.isGroup) return m.reply('Fitur Khusus Group!')
                if (!isBotAdmins) return m.reply("Jadikan *Bot* Sebagai admin")
                let response = await arbakti.groupInviteCode(m.chat)
                m.reply(`https://chat.whatsapp.com/${response}\n\nLink Group : ${groupMetadata.subject}`)
            }
            break
case 'setppgroup': case 'setppgrup': case 'setppgc': {
                if (!m.isGroup) return m.reply('Fitur Khusus Group!')
				if (!isAdmins) return m.reply('Fitur Khusus Admin!')
				if (!isBotAdmins) return m.reply("Jadikan *Bot* Sebagai Admin")
                if (!quoted) return m.reply (`Kirim/Reply Image Dengan Caption ${prefix + command}`)
                if (!/image/.test(mime)) return m.reply (`Kirim/Reply Image Dengan Caption ${prefix + command}`)
                if (/webp/.test(mime)) return m.reply (`Kirim/Reply Image Dengan Caption ${prefix + command}`)
                let media = await arbakti.downloadAndSaveMediaMessage(quoted)
                await arbakti.updateProfilePicture(m.chat, { url: media }).catch((err) => fs.unlinkSync(media))
                m.reply("Berhasil Mengganti pp group")
                }
                break
         case 'setname':
         case 'setnamegc':
         case 'setsubject': {
           if (!m.isGroup) return m.reply('Fitur Khusus Group!')
				if (!isAdmins) return m.reply('Fitur Khusus Admin!')
				if (!isBotAdmins) return m.reply("Jadikan *Bot* Sebagai Admin")
            if (!text) return reply(`Contoh ${prefix+command} bot WhatsApp`)
            await arbakti.groupUpdateSubject(m.chat, text).then((res) => reply("Done")).catch((err) => reply("Terjadi Kesalahan"))
         }
         break
case 'bot':{
            var bot = `Iya Kakak, Ada Yang Bisa ${namabot} Bantu?\nKetik ${prefix}list untuk menampilkan list menu`
            const getTextB = getTextSetBot((m.isGroup? m.chat: botNumber), set_bot);
            if (getTextB !== undefined) {
                var pull_pesan = (getTextB.replace('@bot', namabot).replace('@owner', namaowner).replace('@jam', time).replace('@tanggal', tanggal(new Date())))
                arbakti.sendMessage(m.chat, { text: `${pull_pesan}` }, { quoted: m })
            } else {
                arbakti.sendMessage(m.chat, { text: bot }, { quoted: m })
            }
}
            break
        case 'updatesetbot': case 'setbot': case 'changebot':{
            if (!(m.isGroup? isAdmins : isCreator)) return m.reply('Fitur Khusus admin & owner!')
            if (!q) return reply(`Gunakan dengan cara ${command} *teks_bot*\n\n_Contoh_\n\n${command} Halo saya adalah @bot\n\n@bot = nama bot\n@owner = nama owner\n@jam = jam\n@tanggal = tanggal`)
            if (isSetBot((m.isGroup? m.chat: botNumber), set_bot)) {
                changeSetBot(q, (m.isGroup? m.chat: botNumber), set_bot)
                reply(`Sukses update set bot teks!`)
            } else {
                addSetBot(q, (m.isGroup? m.chat: botNumber), set_bot)
                reply(`Sukses set teks bot!`)
            }
        }
            break
        case 'delsetbot':{
            if (!(m.isGroup? isAdmins : isCreator)) return m.reply('Fitur Khusus admin & owner!')
            if (!isSetBot((m.isGroup? m.chat: botNumber), set_bot)) return reply(`Belum ada set bot di chat ini`)
            removeSetBot((m.isGroup? m.chat: botNumber), set_bot)
            reply(`Sukses delete set bot`)
        }
            break
case 'rename':
            case 'renamelist': {
              if (!(m.isGroup? isAdmins : isCreator)) return m.reply('Fitur Khusus admin & owner!')
                    var args1 = q.split("|")[0].toLowerCase()
                    var args2 = q.split("|")[1]
                    if (!q.includes("|")) return m.reply(`Gunakan dengan cara ${prefix+command} *key|new key*\n\n_Contoh_\n\n${prefix+command} list dm|list dm baru`)
                    if (!isAlreadyResponList((m.isGroup? m.chat: botNumber), args1, db_respon_list)) return m.reply(`Maaf, untuk key *${args1}* belum terdaftar di chat ini`)
                    renameList((m.isGroup? m.chat: botNumber), args1, args2, db_respon_list)
                    reply(`*✅ Done*`)
            }
            break
			case 'updatelist': case 'update':{
   	    // if (!m.isGroup) return m.reply('Fitur Khusus Group!')
			if (!(m.isGroup? isAdmins : isCreator)) return m.reply('Fitur Khusus admin & owner!')
            var args1 = q.split("|")[0].toLowerCase()
            var args2 = q.split("|")[1]
            if (!q.includes("|")) return m.reply(`Gunakan dengan cara ${command} *key|response*\n\n_Contoh_\n\n${command} tes|apa`)
            if (!isAlreadyResponList((m.isGroup? m.chat: botNumber), args1, db_respon_list)) return m.reply(`Maaf, untuk key *${args1}* belum terdaftar di chat ini`)
            if (/image/.test(mime)) {
                let media = await arbakti.downloadAndSaveMediaMessage(quoted)
                let mem = await TelegraPh(media)
                        updateResponList((m.isGroup? m.chat: botNumber), args1, args2, true, mem, db_respon_list)
                        reply(`Sukses update respon list dengan key *${args1}*`)
                        if (fs.existsSync(media)) fs.unlinkSync(media)
            } else {
                updateResponList((m.isGroup? m.chat: botNumber), args1, args2, false, '-', db_respon_list)
                reply(`Sukses update respon list dengan key *${args1}*`)
            }
			}
            break
case 'jeda': {
            if (!m.isGroup) return m.reply('Fitur Khusus Group!')
			if (!isAdmins) return m.reply('Fitur Khusus Admin!')
            if (!isBotAdmins) return m.reply("Jadikan *Bot* Sebagai Admin Terlebih Dahulu")
            if (!text) return m.reply(`kirim ${command} waktu\nContoh: ${command} 30m\n\nlist waktu:\ns = detik\nm = menit\nh = jam\nd = hari`)
            opengc[m.chat] = { id: m.chat, time: Date.now() + toMs(text) }
            fs.writeFileSync('./database/opengc.json', JSON.stringify(opengc))
            arbakti.groupSettingUpdate(m.chat, "announcement")
            .then((res) => reply(`Sukses, group akan dibuka ${text} lagi`))
            .catch((err) => reply('Error'))
            }
            break
case 'tambah':{
	if (!text.includes('+')) return m.reply(`Gunakan dengan cara ${command} *angka* + *angka*\n\n_Contoh_\n\n${command} 1+2`)
arg = args.join(' ')
atas = arg.split('+')[0]
bawah = arg.split('+')[1]
            var nilai_one = Number(atas)
            var nilai_two = Number(bawah)
            reply(`${nilai_one + nilai_two}`)}
            break
        case 'kurang':{
            if (!text.includes('-')) return m.reply(`Gunakan dengan cara ${command} *angka* - *angka*\n\n_Contoh_\n\n${command} 1-2`)
arg = args.join(' ')
atas = arg.split('-')[0]
bawah = arg.split('-')[1]
            var nilai_one = Number(atas)
            var nilai_two = Number(bawah)
            reply(`${nilai_one - nilai_two}`)}
            break
        case 'kali':{
            if (!text.includes('*')) return m.reply(`Gunakan dengan cara ${command} *angka* * *angka*\n\n_Contoh_\n\n${command} 1*2`)
arg = args.join(' ')
atas = arg.split('*')[0]
bawah = arg.split('*')[1]
            var nilai_one = Number(atas)
            var nilai_two = Number(bawah)
            reply(`${nilai_one * nilai_two}`)}
            break
        case 'bagi':{
            if (!text.includes('/')) return m.reply(`Gunakan dengan cara ${command} *angka* / *angka*\n\n_Contoh_\n\n${command} 1/2`)
arg = args.join(' ')
atas = arg.split('/')[0]
bawah = arg.split('/')[1]
            var nilai_one = Number(atas)
            var nilai_two = Number(bawah)
            reply(`${nilai_one / nilai_two}`)}
            break
		case 'setproses': case 'setp':{
		if (!(m.isGroup? isAdmins : isCreator)) return m.reply('Fitur Khusus admin!')
            if (!text) return m.reply(`Gunakan dengan cara ${prefix + command} *teks*\n\n_Contoh_\n\n${prefix + command} Pesanan sedang di proses ya @user\n\n- @user (tag org yg pesan)\n- @pesanan (pesanan)\n- @jam (waktu pemesanan)\n- @tanggal (tanggal pemesanan) `)
            if (isSetProses((m.isGroup? m.chat: botNumber), set_proses)) return m.reply(`Set proses already active`)
            addSetProses(text, (m.isGroup? m.chat: botNumber), set_proses)
            reply(`✅ Done set proses!`)
		}
            break
        case 'changeproses': case 'changep':{
		if (!(m.isGroup? isAdmins : isCreator)) return m.reply('Fitur Khusus admin!')
            if (!text) return m.reply(`Gunakan dengan cara ${prefix + command} *teks*\n\n_Contoh_\n\n${prefix + command} Pesanan sedang di proses ya @user\n\n- @user (tag org yg pesan)\n- @pesanan (pesanan)\n- @jam (waktu pemesanan)\n- @tanggal (tanggal pemesanan) `)
            if (isSetProses((m.isGroup? m.chat: botNumber), set_proses)) {
                changeSetProses(text, (m.isGroup? m.chat: botNumber), set_proses)
                m.reply(`Sukses ubah set proses!`)
            } else {
                addSetProses(text, (m.isGroup? m.chat: botNumber), set_proses)
                m.reply(`Sukses ubah set proses!`)
            }
        }
            break
        case 'delsetproses': case 'delsetp':{
		if (!(m.isGroup? isAdmins : isCreator)) return m.reply('Fitur Khusus admin!')
            if (!isSetProses((m.isGroup? m.chat: botNumber), set_proses)) return m.reply(`Belum ada set proses di gc ini`)
            removeSetProses((m.isGroup? m.chat: botNumber), set_proses)
            reply(`Sukses delete set proses`)
        }
            break
		case 'setdone':{
		if (!(m.isGroup? isAdmins : isCreator)) return m.reply('Fitur Khusus admin!')
			if (!text) return m.reply(`Gunakan dengan cara ${prefix + command} *teks*\n\n_Contoh_\n\n${prefix + command} Done @user\n\n- @user (tag org yg pesan)\n- @pesanan (pesanan)\n- @jam (waktu pemesanan)\n- @tanggal (tanggal pemesanan) `)
            if (isSetDone((m.isGroup? m.chat: botNumber), set_done)) return m.reply(`Udh set done sebelumnya`)
            addSetDone(text, (m.isGroup? m.chat: botNumber), set_done)
            reply(`Sukses set done!`)
            break
            }
           case 'changedone': case 'changed':{
		if (!(m.isGroup? isAdmins : isCreator)) return m.reply('Fitur Khusus admin!')
            if (!text) return m.reply(`Gunakan dengan cara ${prefix + command} *teks*\n\n_Contoh_\n\n${prefix + command} Done @user\n\n- @user (tag org yg pesan)\n- @pesanan (pesanan)\n- @jam (waktu pemesanan)\n- @tanggal (tanggal pemesanan) `)
            if (isSetDone((m.isGroup? m.chat: botNumber), set_done)) {
                changeSetDone(text, (m.isGroup? m.chat: botNumber), set_done)
                m.reply(`Sukses ubah set done!`)
            } else {
                addSetDone(text, (m.isGroup? m.chat: botNumber), set_done)
                m.reply(`Sukses ubah set done!`)
            }
           }
            break
        case 'delsetdone': case 'delsetd':{
		if (!(m.isGroup? isAdmins : isCreator)) return m.reply('Fitur Khusus admin!')
            if (!isSetDone((m.isGroup? m.chat: botNumber), set_done)) return m.reply(`Belum ada set done di gc ini`)
            removeSetDone((m.isGroup? m.chat: botNumber), set_done)
            m.reply(`Sukses delete set done`)
        }
            break
            case"p": case"proses":{
		if (!(m.isGroup? isAdmins : isCreator)) return m.reply('Fitur Khusus admin!')
			if (!m.quoted) return m.reply('Reply pesanan yang akan proses')
            let tek = m.quoted ? quoted.text : quoted.text.split(args[0])[1]
            let proses = `「 *TRANSAKSI PENDING* 」\n\n\`\`\`📆 TANGGAL : @tanggal\n⌚ JAM     : @jam\n✨ STATUS  : Pending\`\`\`\n\n📝 Catatan :\n@pesanan\n\nPesanan @user sedang di proses!`
            const getTextP = getTextSetProses((m.isGroup? m.chat: botNumber), set_proses);
            if (getTextP !== undefined) {
            	var anunya = (getTextP.replace('@pesanan', tek ? tek : '-').replace('@user', '@' + m.quoted.sender.split("@")[0]).replace('@jam', time).replace('@tanggal', tanggal(new Date())).replace('@user', '@' + m.quoted.sender.split("@")[0]))
                arbakti.sendTextWithMentions(m.chat, anunya, m)
            } else {
   arbakti.sendTextWithMentions(m.chat, (proses.replace('@pesanan', tek ? tek : '-').replace('@user', '@' + m.quoted.sender.split("@")[0]).replace('@jam', time).replace('@tanggal', tanggal(new Date())).replace('@user', '@' + m.quoted.sender.split("@")[0])), m)
            }
            }
            break
            case "d": case'done':{
		if (!(m.isGroup? isAdmins : isCreator)) return m.reply('Fitur Khusus admin!')
			if (!m.quoted) return m.reply('Reply pesanan yang telah di proses')
            let tek = m.quoted ? quoted.text : quoted.text.split(args[0])[1]
            let sukses = `「 *TRANSAKSI BERHASIL* 」\n\n\`\`\`📆 TANGGAL : @tanggal\n⌚ JAM     : @jam\n✨ STATUS  : Berhasil\`\`\`\n\nTerimakasih @user Next Order ya🙏`            
            const getTextD = getTextSetDone((m.isGroup? m.chat: botNumber), set_done);
            if (getTextD !== undefined) {
            	var anunya = (getTextD.replace('@pesanan', tek ? tek : '-').replace('@user', '@' + m.quoted.sender.split("@")[0]).replace('@jam', time).replace('@tanggal', tanggal(new Date())).replace('@user', '@' + m.quoted.sender.split("@")[0]))
            	arbakti.sendTextWithMentions(m.chat, anunya, m)
               } else {
               	arbakti.sendTextWithMentions(m.chat, (sukses.replace('@pesanan', tek ? tek : '-').replace('@user', '@' + m.quoted.sender.split("@")[0]).replace('@jam', time).replace('@tanggal', tanggal(new Date())).replace('@user', '@' + m.quoted.sender.split("@")[0])), m)
               }
   }
   break
			case'welcome':{
            if (!m.isGroup) return m.reply('Fitur Khusus Group!')
			if (!isAdmins) return m.reply('Fitur Khusus Admin!')
            if (args[0] === "on") {
               if (isWelcome) return m.reply(`Udah on`)
                _welcome.push(m.chat)
                fs.writeFileSync('./database/welcome.json', JSON.stringify(_welcome, null, 2))
                reply('Sukses mengaktifkan welcome di grup ini')
            } else if (args[0] === "off") {
               if (!isWelcome) return m.reply(`Udah off`)
                let anu = _welcome.indexOf(m.chat)
               _welcome.splice(anu, 1)
                fs.writeFileSync('./database/welcome.json', JSON.stringify(_welcome, null, 2))
                reply('Sukses menonaktifkan welcome di grup ini')
            } else {
                reply(`Kirim perintah ${prefix + command} on/off\n\nContoh: ${prefix + command} on`)
			}
			}
            break
        case'left': case 'goodbye':{
            if (!m.isGroup) return m.reply('Fitur Khusus Group!')
			if (!isAdmins) return m.reply('Fitur Khusus admin!')
            if (args[0] === "on") {
               if (isLeft) return m.reply(`Udah on`)
                _left.push(m.chat)
                fs.writeFileSync('./database/left.json', JSON.stringify(_left, null, 2))
                reply('Sukses mengaktifkan goodbye di grup ini')
            } else if (args[0] === "off") {
               if (!isLeft) return m.reply(`Udah off`)
                let anu = _left.indexOf(m.chat)
               _left.splice(anu, 1)
                fs.writeFileSync('./database/welcome.json', JSON.stringify(_left, null, 2))
                reply('Sukses menonaktifkan goodbye di grup ini')
            } else {
                reply(`Kirim perintah ${prefix + command} on/off\n\nContoh: ${prefix + command} on`)
            }
        }
            break
        	case'setwelcome':{
            if (!m.isGroup) return m.reply('Fitur Khusus Group!')
			if (!isCreator && !isAdmins) return m.reply('Fitur Khusus owner!')
            if (!text) return m.reply(`Gunakan dengan cara ${command} *teks_welcome*\n\n_Contoh_\n\n${command} Halo @user, Selamat datang di @group`)
            if (isSetWelcome(m.chat, set_welcome_db)) return m.reply(`Set welcome already active`)
            addSetWelcome(text, m.chat, set_welcome_db)
           reply(`Successfully set welcome!`)
        	}
            break
        case'changewelcome':{
            if (!m.isGroup) return m.reply('Fitur Khusus Group!')
			if (!isCreator && !isAdmins) return m.reply('Fitur Khusus owner!')
            if (!text) return m.reply(`Gunakan dengan cara ${command} *teks_welcome*\n\n_Contoh_\n\n${command} Halo @user, Selamat datang di @group`)
            if (isSetWelcome(m.chat, set_welcome_db)) {
               changeSetWelcome(q, m.chat, set_welcome_db)
                reply(`Sukses change set welcome teks!`)
            } else {
              addSetWelcome(q, m.chat, set_welcome_db)
                reply(`Sukses change set welcome teks!`)
            }}
            break
        case'delsetwelcome':{
            if (!m.isGroup) return m.reply('Fitur Khusus Group!')
			if (!isCreator && !isAdmins) return m.reply('Fitur Khusus owner!')
            if (!isSetWelcome(m.chat, set_welcome_db)) return m.reply(`Belum ada set welcome di sini..`)
            removeSetWelcome(m.chat, set_welcome_db)
           reply(`Sukses delete set welcome`)
        }
            break
        case'setleft':{
            if (!m.isGroup) return m.reply('Fitur Khusus Group!')
			if (!isCreator && !isAdmins) return m.reply('Fitur Khusus owner!')
            if (!text) return m.reply(`Gunakan dengan cara ${prefix + command} *teks_left*\n\n_Contoh_\n\n${prefix + command} Halo @user, Selamat tinggal dari @group`)
            if (isSetLeft(m.chat, set_left_db)) return m.reply(`Set left already active`)
           addSetLeft(q, m.chat, set_left_db)
            reply(`Successfully set left!`)
        }
            break
        case'changeleft':{
            if (!m.isGroup) return m.reply('Fitur Khusus Group!')
			if (!isCreator && !isAdmins) return m.reply('Fitur Khusus owner!')
            if (!text) return m.reply(`Gunakan dengan cara ${prefix + command} *teks_left*\n\n_Contoh_\n\n${prefix + command} Halo @user, Selamat tinggal dari @group`)
            if (isSetLeft(m.chat, set_left_db)) {
               changeSetLeft(q, m.chat, set_left_db)
                reply(`Sukses change set left teks!`)
            } else {
                addSetLeft(q, m.chat, set_left_db)
                reply(`Sukses change set left teks!`)
            }
        }
            break
        case'delsetleft':{
            if (!m.isGroup) return m.reply('Fitur Khusus Group!')
			if (!isCreator && !isAdmins) return m.reply('Fitur Khusus owner!')
            if (!isSetLeft(m.chat, set_left_db)) return m.reply(`Belum ada set left di sini..`)
            removeSetLeft(m.chat, set_left_db)
            reply(`Sukses delete set left`)
        }
            break
case'antiwame':{
if (!m.isGroup) return m.reply('Fitur Khusus Group!')
if (!isAdmins) return m.reply('Fitur Khusus admin!')
if (!isBotAdmins) return m.reply("Jadikan *Bot* sebagai admin terlebih dahulu")
if (!q) return m.reply(`Ex : ${command} kick on/off\n${command} nokick on/off`)
if (args[0].toLowerCase() === 'kick'){
    if (args[1].toLowerCase() === "on") {
                if (isAntiWame) return m.reply(`Udah aktif`)
                antiwame.push(m.chat)
                fs.writeFileSync('./database/antiwame.json', JSON.stringify(antiwame, null, 2))
                reply('Successfully Activate Antiwame kick In This Group')
    } else if (args[1].toLowerCase() === "off") {
                if (!isAntiWame) return m.reply(`Udah nonaktif`)
                let anu = antiwame.indexOf(m.chat)
                antiwame.splice(anu, 1)
                fs.writeFileSync('./database/antiwame.json', JSON.stringify(antiwame, null, 2))
                reply('Successfully Disabling Antiwame kick In This Group')
            } else {
                m.reply(`Ex : ${command} kick on/off\n${command} nokick on/off`)
            }
} else if (args[0].toLowerCase() === 'nokick'){
             if (args[1].toLowerCase() === "on") {
                if (isAntiWame2) return m.reply(`Udah aktif`)
                antiwame2.push(m.chat)
                fs.writeFileSync('./database/antiwame2.json', JSON.stringify(antiwame2, null, 2))
                reply('Successfully Activate antiwame no kick In This Group')
            } else if (args[1].toLowerCase() === "off") {
                if (!isAntiWame2) return m.reply(`Udah nonaktif`)
                let anu = antiwame2.indexOf(m.chat)
                antiwame2.splice(anu, 1)
                fs.writeFileSync('./database/antiwame2.json', JSON.stringify(antiwame2, null, 2))
                reply('Successfully Disabling antiwame no kick In This Group')
            } else {
              m.reply(`Ex : ${command} kick on/off\n${command} nokick on/off`)
            }
} else {
m.reply(`Ex : ${command} kick on/off\n${command} nokick on/off`)
}
}
            break
  case 'join': {
 if (!isCreator) return m.reply("Fitur khusus owner!")
 if (!text) reply('Masukkan Link Group!')
 if (isUrl(args[0])){
 let result = args[0].split('https://chat.whatsapp.com/')[1]
 await arbakti.groupAcceptInvite(result).then((res) => reply('Sukses Join Grup')).catch((err) => reply('Eror'))
 }}
 break
case 'leavegc': {
if (!isCreator) return m.reply("Fitur khusus owner!")
if (m.isGroup){
reply(`Bot akan keluar dalam 2 detik`)
await sleep(2000)
await arbakti.groupLeave(m.chat).then((res) => reply('Berhasil keluar dari grup tersebut')).catch((err) => reply('Eror'))
} else {
if (!q) return reply(`${command} idgc`)
await arbakti.groupLeave(q).then((res) => reply('Bot telah out')).catch((err) => reply('Eror'))
}}
break
case'addsewa':{
            if (!isCreator) return m.reply("Fitur khusus owner!")
            if (text < 2) return m.reply(`Gunakan dengan cara ${prefix + command} *linkgc waktu*\n\nContoh : ${command} https://chat.whatsapp.com/JanPql7MaMLa 30d\n\n*CATATAN:*\nd = hari (day)\nm = menit(minute)\ns = detik (second)\ny = tahun (year)\nh = jam (hour)`)
            if (!isUrl(args[0])) return reply('Itu Bukan Link')
             if (isUrl(args[0])) {
            var url = args[0]
            url = url.split('https://chat.whatsapp.com/')[1]
            console.log(url)
            if (!args[1]) return m.reply(`Waktunya?`)
            var data = await arbakti.groupAcceptInvite(url)
            if(checkSewaGroup(data, sewa)) return m.reply(`Bot sudah disewa oleh grup tersebut!`)
            addSewaGroup(data, args[0], args[1], sewa)
            reply(`Success Add Sewa Group Berwaktu!`)
           }}
            break
			case'delsewa':{
            if (!isCreator) return m.reply("Fitur khusus owner!")
            if (!m.isGroup) {
            if (!text) return reply('idnya mana?')
            let x = false
              Object.keys(sewa).forEach((i) => {
                if (sewa[i].id === q){x = i}
              })
            sewa.splice(getSewaPosition(sewa[x].id, sewa), 1)
            fs.writeFileSync('./database/sewa.json', JSON.stringify(sewa, null, 2))
            reply(`Success Del Sewa Grup ID ${q}`)
            } else if (m.isGroup){
            if (!isSewa) return m.reply(`Bot tidak disewa di Grup ini`)
            sewa.splice(getSewaPosition(m.chat, sewa), 1)
            fs.writeFileSync('./database/sewa.json', JSON.stringify(sewa, null, 2))
            reply(`Sukses del sewa di grup ini`)
			}}
            break
        case 'ceksewa': case 'listsewa':{
          if (q){
            let rep = ''
            sewa.forEach(async (data) => {
            if (data.id === q){
            exp = data.expired
            if (exp === 'PERMANENT'){
            rep += '*PERMANENT*'
            } else {
            let ex = exp - Date.now()
            rep += `*Expired :* ${msToDate(ex)}`
            }}})
            reply(rep)
          } else {
            let list_sewa_list = `*LIST SEWA*\n\n*Total:* ${sewa.length}\n\n`
            let data_array = [];
            for (let x of sewa) {
list_sewa_list += `*Group* : ${await getGcName(x.id)}
*ID* : ${x.id}
*Creator* : ${await getGcOwn(x.id)}\n`
                if (x.expired === 'PERMANENT') {
                    let ceksewa = 'PERMANENT'
                    list_sewa_list += `*Expire :* PERMANENT\n*Linkgc:* ${x.link}\n\n`
                } else {
                    let ceksewa = x.expired - Date.now()
                    list_sewa_list += `*Expired :* ${msToDate(ceksewa)}\n*Linkgc:* ${x.link}\n\n`
                }
            }
            arbakti.sendMessage(m.chat, { text: list_sewa_list }, { quoted: m })
        }}
            break
			case'open': case'buka':{
            if (!m.isGroup) return m.reply('Fitur Khusus Group!')
				if (!isAdmins) return m.reply('Fitur Khusus Dewa!')
                if (!isBotAdmins) return m.reply("Bot Bukan Dewa")
           arbakti.groupSettingUpdate(m.chat, 'not_announcement')
            const textOpen = await getTextSetOpen(m.chat, set_open);
            reply(textOpen || `「 𝗪𝗘 𝗔𝗥𝗘 𝗢𝗣𝗘𝗡 ✅」`)
			}
			break
case 'antilinkgc':{
if (!m.isGroup) return m.reply('Fitur Khusus Group!')
if (!isAdmins) return m.reply('Fitur Khusus admin!')
if (!isBotAdmins) return m.reply("Bot harus menjadi admin")
if (!q) return m.reply(`Ex : ${command} kick on/off\n${command} nokick on/off`)
if (args[0].toUpperCase() === "NOKICK"){
    try {
        if (args[1] === 'on') {
            if (isAntiLinkgc) return reply('Already Activated');
            antilinkgc.push(m.chat);
            fs.writeFileSync('./database/antilinkgc.json', JSON.stringify(antilinkgc));
            reply('```ANTILINK TELAH AKTIF```');
            arbakti.sendMessage(m.chat, { text: 'ALERT!!! This group has enabled anti-link.\nIf you violate the rule, you will be delete.' });
        } else if (args[1] === 'off') {
            if (!isAntiLinkgc) return reply('Already Deactivated');
            var index = antilinkgc.indexOf(m.chat);
            if (index !== -1) {
                antilinkgc.splice(index, 1);
                fs.writeFileSync('./database/antilinkgc.json', JSON.stringify(antilinkgc));
                reply('```ANTILINK TIDAK AKTIF DI GRUP```');
            }
        } else {
            reply(`Pilih Antilinkgc On / Off`);
        }
    } catch (error) {
        console.error(error);
        reply('Terjadi kesalahan saat menjalankan perintah antilink.');
    }
} else if (args[0].toUpperCase() === "KICK"){
            if (args[1].toLowerCase() === "on") {
               if (isAntiLink) return m.reply(`Udah aktif`)
                antilink.push(m.chat)
                fs.writeFileSync('./database/antilink.json', JSON.stringify(antilink, null, 2))
                reply('Successfully Activate Antilink In This Group')
            } else if (args[1].toLowerCase() === "off") {
               if (!isAntiLink) return m.reply(`Udah nonaktif`)
                let anu = antilink.indexOf(m.chat)
                antilink.splice(anu, 1)
                fs.writeFileSync('./database/antilink.json', JSON.stringify(antilink, null, 2))
                reply('Successfully Disabling Antilink In This Group')
            }
} else {
m.reply(`Ex : ${command} kick on/off\n${command} nokick on/off`)
}
    }
    break;

case'close': case'tutup':{
            if (!m.isGroup) return m.reply('Fitur Khusus Group!')
				if (!isAdmins) return m.reply('Fitur Khusus admin!')
                if (!isBotAdmins) return m.reply("Bot bukan admin")
	    arbakti.groupSettingUpdate(m.chat, 'announcement')
			const textClose = await getTextSetClose(m.chat, set_close);
		    reply(textClose || `「 𝗪𝗘 𝗔𝗥𝗘 𝗖𝗟𝗢𝗦𝗘 ❌」`)
}
		    break
         case 'h':
         case 'woy':
         case 'hidetag':{
            if (!m.isGroup) return reply("Khusus Grup")
            if (!(isAdmins || isCreator)) return reply("Fitur Khusus Para Dewa")
   let tek = m.quoted ? quoted.text : (text ? text : "")
            arbakti.sendMessage(m.chat, {
               text: tek ,
               mentions: participants.map(a => a.id)
            }, {
            })
         }
            break
         case 'sgif':
         case 'stikerin':
         case 's':
         case 'sticker':
         case 'stiker': {
           if (!m.isGroup) return reply("𝘍𝘪𝘵𝘶𝘳 𝘪𝘯𝘪 𝘬𝘩𝘶𝘴𝘶𝘴 𝘥𝘢𝘭𝘢𝘮 𝘨𝘳𝘶𝘱, 𝘶𝘯𝘵𝘶𝘬 𝘮𝘦𝘯𝘨𝘩𝘪𝘯𝘥𝘢𝘳𝘪 𝘴𝘱𝘢𝘮 𝘺𝘢𝘯𝘨 𝘣𝘦𝘳𝘭𝘦𝘣𝘪𝘩𝘢𝘯 𝘥𝘪 𝘱𝘳𝘪𝘷𝘢𝘵𝘦 𝘮𝘦𝘴𝘴𝘢𝘨𝘦")
           if (!quoted) return reply(`Reply foto/video dengan caption ${prefix + command}\n\ndurasi video maks 1-9 detik`)
            if (/image/.test(mime)) {
               let media = await quoted.download()
               let encmedia = await arbakti.sendImageAsSticker(m.chat, media, m, {
                  packname: global.namabot,
                  author: global.namaowner
               })
               await fs.unlinkSync(encmedia)
            } else if (/video/.test(mime)) {
               if ((quoted.msg || quoted).seconds > 11) return reply(`Reply foto/video dengan caption ${prefix + command}\n\ndurasi video maks 1-9 detik`)
               let media = await quoted.download()
               let encmedia = await arbakti.sendVideoAsSticker(m.chat, media, m, {
                  packname: global.namabot,
                  author: global.namaowner
               })
               await fs.unlinkSync(encmedia)
            } else {
               reply(`Reply foto/video dengan caption ${prefix + command}\n\ndurasi video maks 1-9 detik`)
            }
 
         }
         break
    
			case 'kick': {
				if (!m.isGroup) return m.reply('Fitur Khusus Group!')
				if (!isAdmins) return m.reply('Fitur Khusus admin!')
                if (!isBotAdmins) return m.reply('Fitur Khusus admin!')
		let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
		await arbakti.groupParticipantsUpdate(m.chat, [users], 'remove').then((res) => m.reply('Sukses kick target✅')).catch((err) => m.reply('❌ Terjadi kesalahan'))
	}
	break
	case 'ngejak': {
		if (!m.isGroup) return m.reply('Fitur Khusus Group!')
				if (!isAdmins) return m.reply('Fitur Khusus admin!')
                if (!isBotAdmins) return m.reply('Fitur Khusus admin!')
		let users = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
		await arbakti.groupParticipantsUpdate(m.chat, [users], 'ngejak').then((res) => m.reply('Sukses add member✅')).catch((err) => m.reply('❌ Terjadi kesalahan, mungkin nmr nya privat'))
	}
	break

case 'help': 
case 'allmenu': {
  let linkGambar = "https://files.catbox.moe/8fyo6a.jpg";
  let captionGambar = `͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏
⧉ Cukup tulis kata dibawah ini
⧉ Semua ada tutorial dari bot

» owner
» addsewa
» delsewa
» ceksewa
» listsewa
» list
» addlist
» updatelist
» renamelist
» dellist
» jeda
» tambah
» kurang
» kali
» bagi
» setproses
» changeproses
» delsetproses
» setdone
» changedone
» delsetdone
» proses
» done
» welcome
» goodbye
» setwelcome
» changewelcome
» delsetwelcome
» setleft
» changeleft
» delsetleft
» antiwame
» antiwame2
» antilink
» antilink2
» open
» close
» hidetag
» add
» kick
» stiker
» setppgc
» setnamegc
» setdesgc
» linkgc
» resetlinkgc
» promote
» demote
» setbot
» updatesetbot
» delsetbot
» bot

📝 *Note*: 
Fitur nya bisa dipakai dengan atau
tanpa prefix (simbol awalan). Sebagai contoh 
fitur .owner (prefix)
dan bisa juga owner (tanpa prefix)`.trim();

  // Mengirimkan gambar dengan caption
  await arbakti.sendMessage(from, { image: { url: linkGambar }, caption: captionGambar }, { quoted: m });
}
break;

case 'tiktok':
case 'tt': { 	          	           	         	        
if (args.length == 0) return m.reply(`Example: ${prefix + command} link lu`)
const api = require('btch-downloader')
if (!args[0]) return reply(`Masukan URL!\n\ncontoh:\n${prefix + command} https://vm.tiktok.com/ZGJAmhSrp/`);
if (!args[0].match(/tiktok/gi)) return reply(`URL Yang Tuan Berikan *Salah!!!*`);
try {
let maximus = await api.ttdl(args[0]);
let caption = `*arbakti DOWNLOADER* 

❫ *NAMA VIDEO:* 
${maximus.title}

❫ *NAMA AUDIO:* 
${maximus.title_audio}

${global.botname}`;
await arbakti.sendMessage(m.chat, { video: { url: maximus.video[0] }, caption: caption })
await arbakti.sendMessage(m.chat, { audio: { url: maximus.audio[0] }, mimetype: "audio/mpeg", ptt: true }, { quoted: m })
      } catch (e) {
		console.log(e)
		m.reply(e)
	}
}
break

case "brat": {
if (!text) return m.reply('teksnya')
await arbakti.sendMessage(m.chat, {react: {text: '✏️', key: m.key}})
let brat = `https://fgsi-brat.hf.space/?text=${encodeURIComponent(text)}&isVideo=false`
let response = await axios.get(brat, { responseType: "arraybuffer" })
let videoBuffer = response.data;
try {
await arbakti.sendImageAsSticker(m.chat, videoBuffer, m, {packname: global.packname})
} catch {}
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "bratvid":  case "bratvideo": {
if (!text) return m.reply('teksnya')
await arbakti.sendMessage(m.chat, {react: {text: '✏️', key: m.key}})
try {
let brat = `https://fgsi-brat.hf.space/?text=${encodeURIComponent(text)}&isVideo=true`;
let response = await axios.get(brat, { responseType: "arraybuffer" });
let videoBuffer = response.data;
let stickerBuffer = await arbakti.sendVideoAsSticker(m.chat, videoBuffer, m, {
packname: global.packname,
})
} catch (err) {
console.error("Error:", err);
}
}
break

case 'hd': case 'hdr': {  
if (!quoted) return m.reply(`Where is the picture?`)
      	           
	                
			if (!/image/.test(mime)) return m.reply(`Send/Reply Photos With Captions ${prefix + command}`)
			const { remini } = require('./lib/remini')
			let media = await quoted.download()
			let proses = await remini(media, "enhance")
            let proses2 = proses
	 let hade = await remini(proses2, "enhance")
              
              
     arbakti.sendMessage(m.chat, { image: hade, caption: `*Succes*\n${global.botname} • 2024`}, { quoted:m})
			}
			break  

default:
if (budy.startsWith('>')) {
                    if (!isCreator) return
                    try {
                        let evaled = await eval(budy.slice(2))
                        if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
                        await m.reply(evaled)
                    } catch (err) {
                        await m.reply(util.format(err))
                    }
                }
       }
        
    } catch (err) {
        m.reply(util.format(err))
    }
}